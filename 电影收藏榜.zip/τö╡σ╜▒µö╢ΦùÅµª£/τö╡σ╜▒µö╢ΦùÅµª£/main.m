//
//  main.m
//  电影收藏榜
//
//  Created by mac on 16/7/4.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
