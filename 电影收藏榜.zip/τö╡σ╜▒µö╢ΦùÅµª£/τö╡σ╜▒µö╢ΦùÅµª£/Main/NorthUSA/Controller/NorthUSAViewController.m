//
//  NorthUSAViewController.m
//  电影收藏榜
//
//  Created by mac on 16/7/4.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "NorthUSAViewController.h"
#import "NorthModel.h"
#import "USACell.h"
#import "Common.pch"
#import "PostView.h"


@class NorthModel;
@interface NorthUSAViewController ()<UITableViewDelegate,UITableViewDataSource> {
    
    UITableView *_tbview;
    PostView *_posterView;
    NSMutableArray *_dataArr;

    
}

@end

@implementation NorthUSAViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"北美榜";
    [self _loadview];
    [self _loadTableView];
    [self _loadPosterView];
    [self _loadJson];
    
    _tbview.rowHeight = 120;
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    UIImageView *footView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0,kScreenWidth , kScreenHeight)];
    footView.image = [UIImage imageNamed:@"yasuo.jpg"];
    _tbview.tableFooterView = footView;
    
}

- (void)_loadJson {
    
    _dataArr = [NSMutableArray arrayWithCapacity:0];
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"us_box" ofType:@"json"];
    NSDate *data = [NSData dataWithContentsOfFile:filePath];
    id dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:NULL];
    NSArray *subjects = dic[@"subjects"];
    NSLog(@"%@",dic);
    
    for (NSDictionary *jsonDic in subjects) {
        
        NorthModel *model = [[NorthModel alloc] init];
        NSDictionary *subject = jsonDic[@"subject"];
        model.rating = subject[@"rating"];
        model.title = subject[@"title"];
        model.year = subject[@"year"];
        model.original_titles = subject[@"orginal_title"];
        model.images = subject[@"images"];
        [_dataArr addObject:model];
        
    }
    _posterView.data = _dataArr;
   
    
    
}

- (void)_loadview {
    
    UIView *buttonview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    button1.frame = buttonview.bounds;
    [button1 setBackgroundImage:[UIImage imageNamed:@"exchange_bg_home"] forState:UIControlStateNormal];
    [button1 setImage:[UIImage imageNamed:@"list_home"] forState:UIControlStateNormal];
    button1.tag = 200;
    [button1 addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [buttonview addSubview:button1];
    
    UIButton *button2 = [UIButton buttonWithType:UIButtonTypeCustom];
    button2.frame = buttonview.bounds;
    [button2 setBackgroundImage:[UIImage imageNamed:@"exchange_bg_home"] forState:UIControlStateNormal];
    [button2 setImage:[UIImage imageNamed:@"poster_home"] forState:UIControlStateNormal];
    button2.tag = 201;
    button2.hidden = YES;
    [button2 addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [buttonview addSubview:button2];
    
    
    UIBarButtonItem *rightitem = [[UIBarButtonItem alloc] initWithCustomView:buttonview];
    self.navigationItem.rightBarButtonItem = rightitem;
    
    
    
}

- (void)_loadTableView {
    
    _tbview = [[UITableView alloc] initWithFrame:self.view.bounds];
    _tbview.delegate = self;
    _tbview.dataSource = self;
    _tbview.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]];
    [self.view addSubview:_tbview];
    
    
    
}

- (void)_loadPosterView {
    
    _posterView = [[PostView alloc] initWithFrame:self.view.bounds];
    _posterView.backgroundColor = [UIColor orangeColor];
    _posterView.hidden = YES;
    [self.view insertSubview:_posterView atIndex:0];
}

- (void)buttonAction:(UIButton *)button {
    
    UIView *buttonView = self.navigationItem.rightBarButtonItem.customView;
    
    UIButton *button1 = (UIButton *)[buttonView viewWithTag:200];
    UIButton *button2 = (UIButton *)[buttonView viewWithTag:201];
    
    button1.hidden = !button1.hidden;
    button2.hidden = !button2.hidden;
    
    
    _posterView.hidden = !_posterView.hidden;
    _tbview.hidden = !_tbview.hidden;
    
    [self flip:buttonView left:button1.hidden];
    [self flip:self.view left:button1.hidden];
}

- (void)flip:(UIView *)forview left:(BOOL)flag {
    
    UIViewAnimationOptions flip = flag?
UIViewAnimationOptionTransitionFlipFromLeft:
    UIViewAnimationOptionTransitionFlipFromRight;
    [UIView transitionWithView:forview duration:0.3 options:flip animations:^{
        [forview exchangeSubviewAtIndex:0 withSubviewAtIndex:1];
    }completion:NULL];


}

#pragma mark 

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _dataArr.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellID =@"cellID";
    USACell *cell = [_tbview dequeueReusableCellWithIdentifier:cellID];
    if(cell == nil) {
        
        cell = [[[NSBundle mainBundle] loadNibNamed:@"USACell" owner:self options:nil]lastObject];
    }
    cell.model = _dataArr[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    
    return 115;
}


@end
