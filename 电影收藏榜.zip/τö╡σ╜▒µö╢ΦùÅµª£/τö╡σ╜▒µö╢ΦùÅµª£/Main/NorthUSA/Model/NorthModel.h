//
//  NorthModel.h
//  项目一
//
//  Created by mac on 16/7/5.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NorthModel : NSObject

@property(strong,nonatomic)NSDictionary *rating;
@property(copy,nonatomic)NSString *title;
@property(copy,nonatomic)NSString *year;
@property(copy,nonatomic)NSString *original_titles;
@property(strong,nonatomic)NSDictionary *images;

@end
