//
//  NorthModel.m
//  项目一
//
//  Created by mac on 16/7/5.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "NorthModel.h"

@implementation NorthModel

@end
