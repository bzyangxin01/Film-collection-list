//
//  USACell.h
//  电影收藏榜
//
//  Created by mac on 16/1/5.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NorthModel.h"
#import "startView.h"
@class startView;
@interface USACell : UITableViewCell {
    
    __weak IBOutlet UIImageView *imgView;
    
    __weak IBOutlet UILabel *titleLabel;
    
    __weak IBOutlet UILabel *ratingLabel;
    
    __weak IBOutlet UILabel *yearLabel;
    
   
    __weak IBOutlet startView *StartView;
    
}

@property(strong,nonatomic)NorthModel *model;

@end
