//
//  HeadCollectionView.m
//  项目一
//
//  Created by mac on 16/7/9.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "HeadCollectionView.h"
#import "HeadCell.h"

@implementation HeadCollectionView
{
    
   
}

- (instancetype)initWithFrame:(CGRect)frame {
    
    UICollectionViewFlowLayout *flowlayout = [[UICollectionViewFlowLayout alloc] init];
    flowlayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    flowlayout.minimumLineSpacing = 0;
    
    self = [super initWithFrame:frame collectionViewLayout:flowlayout];
    if(self) {
        
        
        
        self.delegate = self;
        self.dataSource = self;
        
        flowlayout.itemSize = CGSizeMake(80, self.frame.size.height);
        
        
        [self registerClass:[HeadCell class] forCellWithReuseIdentifier:@"idSmall"];
        
    }
    return self;
}

- (void)setData:(NSArray *)data{
    _data = data;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return _data.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    HeadCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"idSmall" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor grayColor];
    
    cell.model =  _data[indexPath.row];
    
    return cell;
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    
    CGFloat offetX = (CGRectGetWidth(self.frame)-_PageWidth)/2;
    
    return UIEdgeInsetsMake(0, offetX, 0, offetX);
    
}

- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset {
    int index = (targetContentOffset->x + _PageWidth/2)/_PageWidth;
    
    //设置界面
    if (index == _currentItem) {
        
        //向右滑动,快速的滑动块的话,直接到下一页
        if (velocity.x > 0.4)
        {
            index++;
        }else if (velocity.x < -0.4)
        {
            index--;
        }
    }
    
    targetContentOffset->x = _PageWidth*index;
    
    self.currentItem = index;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
   
    
    
    //让单元格选中居中显示
    [collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
    
    self.currentItem = indexPath.row;
}


@end
