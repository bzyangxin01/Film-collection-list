//
//  PostCollectionView.h
//  项目一
//
//  Created by mac on 16/7/9.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PostCollectionView : UICollectionView<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property(assign,nonatomic)CGFloat pageWidth;


//从PosterView获取数据
@property (strong,nonatomic)NSArray *data;

@property(assign,nonatomic)NSInteger currentItem;

@end
