//
//  USACell.m
//  项目一
//
//  Created by mac on 16/7/5.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "USACell.h"
#import "UIImageView+WebCache.h"
#import "startView.h"
@implementation USACell

- (void)setModel:(NorthModel *)model {
    
    _model = model;
    titleLabel.text = model.title;
    yearLabel.text = model.year;
    NSNumber *rating = model.rating[@"average"];
    ratingLabel.text = [rating stringValue];
    
    NSString *imageName = model.images[@"medium"];
    
    [imgView sd_setImageWithURL:[NSURL URLWithString:imageName] placeholderImage:[UIImage imageNamed:@"yasuo.jpg"]];
    
    CGFloat s = [model.rating[@"average"] floatValue];
    StartView.rating = s;
}

@end
