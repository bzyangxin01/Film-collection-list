//
//  PostCollectionView.m
//  项目一
//
//  Created by mac on 16/7/9.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "PostCollectionView.h"
#import "PostCell.h"

@implementation PostCollectionView {
    
    NSString *indentify;
}


- (instancetype)initWithFrame:(CGRect)frame {
    
    UICollectionViewFlowLayout *flowlayout = [[UICollectionViewFlowLayout alloc] init];
    flowlayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    flowlayout.minimumLineSpacing = 0;
    
    self = [super initWithFrame:frame collectionViewLayout:flowlayout];
    if(self) {
        
        
        
        self.delegate = self;
        self.dataSource = self;
        
        flowlayout.itemSize = CGSizeMake(220, self.frame.size.height);
        indentify = @"identify";
        
        [self registerClass:[PostCell class] forCellWithReuseIdentifier:indentify];
        
    }
    return self;
}

- (void)setData:(NSArray *)data{
    _data = data;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return _data.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    PostCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:indentify forIndexPath:indexPath];
    cell.backgroundColor = [UIColor grayColor];
    
      cell.model =  _data[indexPath.row];
    return cell;
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    
    CGFloat offetX = (CGRectGetWidth(self.frame)-_pageWidth)/2;
    
    return UIEdgeInsetsMake(0, offetX, 0, offetX);
    
}

- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset {
    
    NSInteger index = (targetContentOffset->x + _pageWidth/2)/_pageWidth;
    
    if(index == _currentItem) {
        
        if (velocity.x > 0.4)
        {
            index++;
        }else if (velocity.x < -0.4)
        {
            index--;
        }

    }
    
    targetContentOffset->x = index*_pageWidth;
    self.currentItem = index;
}


//选中单元格事件
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    /*
     PosterCell * cell  = (PosterCell *)[collectionView cellForItemAtIndexPath:indexPath];
     [cell filpCell];
     */
    
    if (self.currentItem == indexPath.item)
    {
        PostCell * cell  = (PostCell *)[collectionView cellForItemAtIndexPath:indexPath];
        [cell filpCell];
    }else
    {
        //让单元格选中居中显示
        [collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
    }
    self.currentItem = indexPath.row;
}


@end
