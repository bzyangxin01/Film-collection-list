//
//  HeadCell.m
//  电影收藏榜
//
//  Created by mac on 16/1/9.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "HeadCell.h"
#import "NorthModel.h"
#import "UIImageView+WebCache.h"

@implementation HeadCell
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        //创建视图
        [self _createView];
    }
    return self;
}


- (void)_createView{
    
    self.contentView.transform = CGAffineTransformMakeScale(0.95, 0.95);
    //1:创建imgeView
    _imgeView = [[UIImageView alloc] initWithFrame:self.contentView.bounds];
    
    [self.contentView addSubview:_imgeView];
}

-(void)setModel:(NorthModel *)model{
    _model = model;
    
    //获取url地址
    NSString * url = [_model.images objectForKey:@"small"];
    
    [_imgeView sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:@"yasuo.jpg"]];
    
    
}

@end
