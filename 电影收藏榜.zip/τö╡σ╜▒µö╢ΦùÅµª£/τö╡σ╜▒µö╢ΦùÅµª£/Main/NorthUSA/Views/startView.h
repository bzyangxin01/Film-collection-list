//
//  startView.h
//  项目一
//
//  Created by mac on 16/7/6.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "USACell.h"

@interface startView : UIView {
    
    UIView *_yellowView;
    
    UIView *_grayView;
}

@property(assign,nonatomic)CGFloat rating;


@end
