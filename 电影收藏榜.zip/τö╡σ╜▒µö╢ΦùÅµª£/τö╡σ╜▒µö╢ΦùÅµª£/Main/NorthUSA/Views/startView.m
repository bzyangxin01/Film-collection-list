//
//  startView.m
//  电影收藏榜
//
//  Created by mac on 16/7/6.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "startView.h"
#import "USACell.h"
@implementation startView


- (void)awakeFromNib {
    
    [self _createView];
}

- (void)_createView {
    
    UIImage *yellowImg = [UIImage imageNamed:@"yellow"];
    UIImage *grayImg = [UIImage imageNamed:@"gray"];
    
    _grayView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, grayImg.size.width*5, grayImg.size.height)];
    _grayView.backgroundColor = [UIColor colorWithPatternImage:grayImg];
    [self addSubview:_grayView];
    
    _yellowView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, yellowImg.size.width*5, yellowImg.size.height)];
    _yellowView.backgroundColor = [UIColor colorWithPatternImage:yellowImg];
    [self addSubview:_yellowView];
    
    self.backgroundColor = [UIColor clearColor];
    
    
    CGFloat star5Width = self.frame.size.height*5;
    CGRect frame = self.frame;
    frame.size.width = star5Width;
    self.frame = frame;
    
    CGFloat scale = self.frame.size.height/yellowImg.size.height;
    
    CGAffineTransform t = CGAffineTransformMakeScale(scale, scale);
    _yellowView.transform = t;
    _grayView.transform = t;
    
    CGRect f1 = _grayView.frame;
    CGRect f2 = _yellowView.frame;
    f1.origin = CGPointZero;
    f2.origin = CGPointZero;
    
    _grayView.frame = f1;
    _yellowView.frame = f2;
}

- (void)setRating:(CGFloat)rating {
    
    

                  
    _rating = rating;
    CGFloat s= rating/10.0;
    
    CGFloat width = s*self.frame.size.width;
    CGRect frame = _yellowView.frame;
    frame.size.width = width;
    _yellowView.frame = frame;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
