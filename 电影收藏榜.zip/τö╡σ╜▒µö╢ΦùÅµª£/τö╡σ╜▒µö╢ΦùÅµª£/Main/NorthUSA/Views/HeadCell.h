//
//  HeadCell.h
//  项目一
//
//  Created by mac on 16/7/9.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NorthModel;

@interface HeadCell : UICollectionViewCell
{
    
    UIImageView *_imgeView;
}

@property(copy,nonatomic)NorthModel *model;

@end
