//
//  PostView.h
//  项目一
//
//  Created by mac on 16/7/9.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PostCollectionView.h"


@interface PostView : UIView {
    
    UIView *headView;
    UIButton *button1;
    PostCollectionView *_postCollectionView;
    UILabel *_footLabel;
}

- (instancetype)initWithFrame:(CGRect)frame;

//从NorthViewController里面获取数据
@property (strong,nonatomic)NSArray *data;


@end
