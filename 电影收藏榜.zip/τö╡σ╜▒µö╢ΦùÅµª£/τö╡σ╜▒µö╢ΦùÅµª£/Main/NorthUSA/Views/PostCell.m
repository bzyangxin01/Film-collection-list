//
//  PostCell.m
//  项目一
//
//  Created by mac on 16/7/9.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "PostCell.h"
#import "NorthModel.h"
#import "UIImageView+WebCache.h"


@implementation PostCell {
    
    BOOL left;
}

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
         left = YES;
        //创建视图
        [self _createView];
    }
    return self;
}


- (void)filpCell
{
    left =! left;
    
    UIViewAnimationOptions transtion = left ? UIViewAnimationOptionTransitionFlipFromLeft:UIViewAnimationOptionTransitionFlipFromRight;
    
    //使用翻转动画
    [UIView transitionWithView:self.contentView duration:0.5 options:transtion animations:^{
        
        //交换显示视图 根据下标
        [self.contentView exchangeSubviewAtIndex:0 withSubviewAtIndex:1];
    } completion:NULL];
}



- (void)_createView{
    
    self.contentView.transform = CGAffineTransformMakeScale(0.95, 0.95);
    
    //创建视图
    _imgeView  = [[UIImageView alloc] initWithFrame:self.contentView.bounds];
    
    _imgeView.backgroundColor  = [UIColor greenColor];
    
    [self.contentView addSubview:_imgeView];
    
    //2:创建翻转视图
    _datailView = [[UIView alloc] initWithFrame:self.contentView.bounds];
    _datailView.backgroundColor = [UIColor whiteColor];
    //把_datailView视图放到_imgaeView视图的下面
    [self.contentView insertSubview:_datailView belowSubview:_imgeView];
}

-(void)setModel:(NorthModel *)model{
    _model = model;
    
    //获取url地址
    NSString * url = [_model.images objectForKey:@"large"];
    
    [_imgeView sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:@"yasuo.jpg"]];
    
    
}

@end
