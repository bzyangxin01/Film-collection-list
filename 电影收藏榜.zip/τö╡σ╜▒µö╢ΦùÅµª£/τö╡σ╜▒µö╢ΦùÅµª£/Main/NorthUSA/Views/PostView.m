//
//  PostView.m
//  电影收藏榜
//
//  Created by mac on 16/1/9.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "PostView.h"
#import "PostCollectionView.h"
#import "PostCell.h"
#import "HeadCollectionView.h"
#import "NorthModel.h"


@implementation PostView {
    
    UIControl *_maskView;
    
    HeadCollectionView *_headCollectionView;
}

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        
        [self _createView];
        
        [self _createPostView];
        
        [self _createfootLabel];
        
        [_postCollectionView addObserver:self forKeyPath:@"currentItem" options:NSKeyValueObservingOptionNew context:nil];
        
        [_headCollectionView addObserver:self forKeyPath:@"currentItem" options:NSKeyValueObservingOptionNew context:nil];
        

    }
    return self;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    NSLog(@"change=%@",change);
    
    NSNumber *newValue = [change objectForKey:@"new"];
   
    NSInteger item1 = [newValue integerValue];
    
    if(object == _postCollectionView && _headCollectionView.currentItem != item1){
    
    
   _headCollectionView.currentItem = item1;
    
    NSIndexPath  *indexPath = [NSIndexPath indexPathForItem:item1 inSection:0];
    
    if (item1 < 0) {
        
        return;
    }
    
 
    [_headCollectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        
    }else if(object == _headCollectionView &&_postCollectionView.currentItem != item1) {
        
        _postCollectionView.currentItem = item1;
        
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:item1 inSection:0];
        if(item1 <0 || item1 > _data.count) {
            
            return;
        }
        
        [_postCollectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
    }
    NorthModel *model = _data[item1];
    _footLabel.text = model.title;
    
    
        
}








- (void)_createView {
    
    headView = [[UIView alloc] initWithFrame:CGRectMake(0, -100, [UIScreen mainScreen].bounds.size.width, 130)];
    headView.backgroundColor = [UIColor greenColor];
    [self addSubview:headView];
    
    UIImage *img = [UIImage imageNamed:@"indexBG_home"];
    img = [img stretchableImageWithLeftCapWidth:0 topCapHeight:1];
    
    
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 130)];
    imgView.image = img;
    [headView addSubview:imgView];
    
    _headCollectionView = [[HeadCollectionView alloc] initWithFrame:CGRectMake(0, -10, [UIScreen mainScreen].bounds.size.width, headView.frame.size.height)];
    _headCollectionView.backgroundColor = [UIColor yellowColor];
    
    _headCollectionView.PageWidth = 80;
    [headView insertSubview:_headCollectionView aboveSubview:imgView];
    
    button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 setImage:[UIImage imageNamed:@"down_home"] forState:UIControlStateNormal];
    [button1 setImage:[UIImage imageNamed:@"up_home"] forState:UIControlStateSelected];
    button1.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width-20)/2, 130-20, 20, 20);
    [button1 addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    button1.selected = NO;
    
    
    
    [headView addSubview:button1];
    
    UISwipeGestureRecognizer *swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipe:)];
    swipe.direction = UISwipeGestureRecognizerDirectionDown;
    [self addGestureRecognizer:swipe];
}

- (void)_createPostView {
    
    _postCollectionView = [[PostCollectionView alloc] initWithFrame:CGRectMake(0, 40, [UIScreen mainScreen].bounds.size.width, self.frame.size.height-64-149)];
    _postCollectionView.backgroundColor = [UIColor yellowColor];
    
    _postCollectionView.pageWidth = 220;
    
    [self insertSubview:_postCollectionView belowSubview:headView];
    
    

    
}

- (void)_createfootLabel {
    
    _footLabel = [[UILabel alloc] init];
    _footLabel.frame = CGRectMake(0, self.frame.size.height-202, [UIScreen mainScreen].bounds.size.width, 40);
    
    _footLabel.textAlignment = NSTextAlignmentCenter;
    _footLabel.textColor = [UIColor whiteColor];
    
    
    [self addSubview:_footLabel];
}

-(void)setData:(NSArray *)data{
    _data = data;
    
    _postCollectionView.data = _data;
    
    _headCollectionView.data = _data;
    
    NorthModel *model = _data[0];
    _footLabel.text = model.title;
}


- (void)swipe:(UISwipeGestureRecognizer *)swipe {
    
    //NSLog(@"唐宇鹏彩笔");
    [self _showHeadView];
}

- (void)buttonAction:(UIButton *)button {
    
     button.selected = !button.selected;
    //NSLog(@"唐宇鹏彩笔");
    if(button.selected == YES) {
        
        headView.transform = CGAffineTransformMakeTranslation(0, 100);
        _maskView.hidden = NO;
    }else {
        
        headView.transform = CGAffineTransformIdentity;
        _maskView.hidden = YES;
    }
    
    
}

- (void)_showHeadView {
    
    headView.transform = CGAffineTransformMakeTranslation(0, 100);
    
    button1.selected = YES;
    
    if(_maskView == nil) {
    
    _maskView = [[UIControl alloc] initWithFrame:self.bounds];
    _maskView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
    [_maskView addTarget:self action:@selector(maskViewAction:) forControlEvents:UIControlEventTouchUpInside];
    [self insertSubview:_maskView belowSubview:headView];
        
    }
    _maskView.hidden = NO;
}

- (void)maskViewAction:(UIControl *)control {
    
    NSLog(@"蒙牛不好喝");
}

@end
