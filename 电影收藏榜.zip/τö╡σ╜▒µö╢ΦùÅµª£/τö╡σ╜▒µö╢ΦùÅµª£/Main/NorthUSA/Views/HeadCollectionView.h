//
//  HeadCollectionView.h
//  电影收藏榜
//
//  Created by mac on 16/1/9.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeadCollectionView : UICollectionView<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property(assign,nonatomic)CGFloat PageWidth;

@property (strong,nonatomic)NSArray *data;

@property (assign,nonatomic)NSInteger currentItem;

@end
