//
//  NewsCollectionModel.m
//  电影收藏榜
//
//  Created by mac on 16/1/7.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "NewsCollectionModel.h"

@implementation NewsCollectionModel

@end
