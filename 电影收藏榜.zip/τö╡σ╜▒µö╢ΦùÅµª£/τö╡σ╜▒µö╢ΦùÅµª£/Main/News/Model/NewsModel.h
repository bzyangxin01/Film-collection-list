//
//  NewsModel.h
//  项目一
//
//  Created by mac on 16/7/6.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef enum {
    
    WordType,ImgType,VideoType
    
}NewsType;

@interface NewsModel : NSObject


@property(assign,nonatomic)NSInteger newsid;
@property(assign,nonatomic)NewsType type;
@property(copy,nonatomic)NSString *title;
@property(copy,nonatomic)NSString *summary;
@property(copy,nonatomic)NSString *image;

@end
