//
//  NewsCollectionModel.h
//  项目一
//
//  Created by mac on 16/7/7.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsCollectionModel : NSObject



@property(copy,nonatomic)NSString *image;
@property(assign,nonatomic)NSInteger ID;
@property(assign,nonatomic)NSInteger type;

@end
