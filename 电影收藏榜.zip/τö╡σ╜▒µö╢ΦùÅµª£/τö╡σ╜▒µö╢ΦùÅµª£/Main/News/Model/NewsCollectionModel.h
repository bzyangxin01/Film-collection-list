//
//  NewsCollectionModel.h
//  电影收藏榜
//
//  Created by mac on 16/1/7.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsCollectionModel : NSObject



@property(copy,nonatomic)NSString *image;
@property(assign,nonatomic)NSInteger ID;
@property(assign,nonatomic)NSInteger type;

@end
