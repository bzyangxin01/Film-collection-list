//
//  WordController.h
//  项目一
//
//  Created by mac on 16/7/6.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "BaseViewController.h"

@interface WordController : BaseViewController

@end
