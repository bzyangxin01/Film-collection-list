//
//  NewsViewController.h
//  电影收藏榜
//
//  Created by mac on 16/7/4.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "BaseViewController.h"

@interface NewsViewController : BaseViewController

@end
