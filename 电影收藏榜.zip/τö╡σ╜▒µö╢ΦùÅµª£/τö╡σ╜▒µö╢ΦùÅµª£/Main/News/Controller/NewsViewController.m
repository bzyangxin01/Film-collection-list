//
//  NewsViewController.m
//  项目一
//
//  Created by mac on 16/7/4.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "NewsViewController.h"
#import "WXDataService.h"
#import "Common.h"
#import "NewsModel.h"
#import "UIImageView+WebCache.h"
#import "NewsCell.h"
@class WXDataService;
@interface NewsViewController ()<UITableViewDelegate,UITableViewDataSource> {
    
    UIImageView *imgView;
    NSMutableArray *_dataArr;
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation NewsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"新闻";
    
    [self _loadData];
    
    [self _createUI];
    _tableView.delegate = self;
    _tableView.dataSource =self;
    
    _tableView.rowHeight = 120;
}

- (void)_loadData {
    
   NSArray *jsonArr = [WXDataService loadData:@"news_list.json"];
    
    _dataArr = [NSMutableArray arrayWithCapacity:jsonArr.count];
    for (NSDictionary *dic in jsonArr) {
        NewsModel *model = [[NewsModel alloc] init];
        model.title = dic[@"title"];
        model.summary = dic[@"summary"];
        model.newsid = [dic[@"newsid"] integerValue];
        model.image = dic[@"image"];
        model.type = (NewsType)[dic[@"type"] integerValue];
        
        [_dataArr addObject:model];
    }
    
}

- (void)_createUI
{
    NewsModel *model = _dataArr[0];
    [_dataArr removeObjectAtIndex:0];
    
    imgView = [[UIImageView alloc] init];
    imgView.frame = CGRectMake(0, 64, [UIScreen mainScreen].bounds.size.width, 150);
    [imgView sd_setImageWithURL:[NSURL URLWithString:model.image] placeholderImage:[UIImage imageNamed:@"yasuo"]];
    [self.view insertSubview:imgView belowSubview:_tableView];
    _tableView.backgroundColor = [UIColor clearColor];
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 150)];
    headView.backgroundColor = [UIColor clearColor];
    _tableView.tableHeaderView = headView;
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat y = scrollView.contentOffset.y;
    
    if(y<0) {
        
        CGFloat width = (150-y)/150 *[UIScreen mainScreen].bounds.size.width;
        CGFloat height = 150-y;
        imgView.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width-width)/2, 64, width, height);
    }else {
        
        imgView.frame = CGRectMake(0, -y+64, [UIScreen mainScreen].bounds.size.width, 150);
    }
    NSLog(@"y:%f",scrollView.contentOffset.y);
}

#pragma mark  --

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //    return nil;
    static NSString *cellID = @"cellID";
    NewsCell * cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        //获取xib
        cell  = [[[NSBundle mainBundle] loadNibNamed:@"NewsCell" owner:self options:nil]lastObject];
    }
    
    //传输数据
    cell.model = _dataArr[indexPath.row];
    

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NewsModel *model = _dataArr[indexPath.row];
    NSString *viewctrID= nil;
    int type = model.type;
    
    if(type == WordType) {
        
        viewctrID = @"WordControllerID";
        
    }else if(type == ImgType) {
        
        viewctrID = @"ImageViewControllerID";
        
    }else {
        return;
    }
    
    UIViewController *viewctr = [self.storyboard instantiateViewControllerWithIdentifier:viewctrID];
    viewctr.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:viewctr animated:YES];
}




@end
