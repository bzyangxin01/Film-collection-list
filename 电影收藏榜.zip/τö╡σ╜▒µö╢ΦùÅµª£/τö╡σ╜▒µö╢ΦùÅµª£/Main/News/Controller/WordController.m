//
//  WordController.m
//  电影收藏榜
//
//  Created by mac on 16/7/6.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "WordController.h"

@interface WordController ()<UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation WordController

- (void)viewDidLoad {
    [super viewDidLoad];

    _webView.delegate = self;
    
    NSURL *url = [NSURL URLWithString:@"http://movie.douban.com/celebrity/1002667/"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [self.webView loadRequest:request];
    
    // Do any additional setup after loading the view.
    
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    
    NSLog(@"将开始加载");
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView {
    
    NSLog(@"已经开始加载");
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
    NSLog(@"加载完成");
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error {
    
    NSLog(@"加载失败");
}

@end
