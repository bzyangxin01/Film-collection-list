//
//  ImageViewController.m
//  电影收藏榜
//
//  Created by mac on 16/7/6.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "ImageViewController.h"
#import "WXDataService.h"
#import "UIImageView+WebCache.h"
#import "NewsCollectionModel.h"
#import "imageCell.h"
#import "PhotoViewController.h"

#define KItemWidth 90
#define KItemHeight 80
#define KItemCount 3

#define KItemSpace ([UIScreen mainScreen].bounds.size.width-KItemWidth*KItemCount)/(KItemCount+5)

@class WXDataService;

@interface ImageViewController ()<UICollectionViewDelegateFlowLayout,UICollectionViewDataSource> {
    
    NSMutableArray *_dataArr;
    
}

@property (weak, nonatomic) IBOutlet UICollectionViewFlowLayout *flowlayout;


@end

@implementation ImageViewController

//设置全局的静态名字
static  NSString * celID = @"cellID";


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.title = @"图片";
    
    
    
    [self _loadData];
    
    [self createUI];
    
    self.edgesForExtendedLayout = UIRectEdgeNone;
   
}

- (void)_loadData {
    
    NSArray *jsonArr = [WXDataService loadData:@"image_list.json"];
    
    _dataArr = [NSMutableArray arrayWithCapacity:jsonArr.count];
    
    for (NSDictionary *dic in jsonArr) {
        
        NewsCollectionModel *model = [[NewsCollectionModel alloc] init];
        
        model.image = dic[@"image"];
        model.ID = [dic[@"id"] integerValue];
        model.type = [dic[@"type"] integerValue];
        
        
        [_dataArr addObject:model];
    }

}

- (void)createUI {
    
    self.flowlayout.itemSize = CGSizeMake(KItemWidth, KItemHeight);
    self.flowlayout.minimumLineSpacing = KItemSpace;
    self.flowlayout.minimumInteritemSpacing = KItemSpace;
    self.flowlayout.sectionInset = UIEdgeInsetsMake(KItemSpace, KItemSpace, 0, KItemSpace);
    
}

#pragma mark -- UICollectionViewDataSource



- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return _dataArr.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    imageCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"imageCell" forIndexPath:indexPath];
    cell.model = _dataArr[indexPath.row];
    return cell;
    
    }

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    PhotoViewController *photovc = [[PhotoViewController alloc] init];
    photovc.selectionIndexPath = indexPath;
    
    NSMutableArray *newArr = [NSMutableArray arrayWithCapacity:_dataArr.count];
    for (NewsCollectionModel *model in _dataArr) {
        [newArr addObject:model.image];
    }
    photovc.imageUrl = newArr;
    
    [self.navigationController pushViewController:photovc animated:YES];
    
}

@end
