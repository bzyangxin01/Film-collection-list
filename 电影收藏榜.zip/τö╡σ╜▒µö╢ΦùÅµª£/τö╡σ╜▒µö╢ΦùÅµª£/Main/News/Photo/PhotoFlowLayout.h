//
//  PhotoFlowLayout.h
//  项目一
//
//  Created by mac on 16/7/8.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoFlowLayout : UICollectionViewFlowLayout

@end
