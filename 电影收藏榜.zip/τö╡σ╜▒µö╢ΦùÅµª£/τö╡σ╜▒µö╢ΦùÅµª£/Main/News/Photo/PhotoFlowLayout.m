//
//  PhotoFlowLayout.m
//  电影收藏榜
//
//  Created by mac on 16/1/8.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "PhotoFlowLayout.h"

@implementation PhotoFlowLayout

- (instancetype)init {
    
    self = [super init];
    if(self) {
        
        self.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        self.minimumLineSpacing = 0;
        
        self.itemSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-80);
        
    }
    return self;
}
@end
