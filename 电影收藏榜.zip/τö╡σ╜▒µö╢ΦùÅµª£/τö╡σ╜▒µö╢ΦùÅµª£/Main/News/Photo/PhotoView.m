//
//  PhotoView.m
//  项目一
//
//  Created by mac on 16/7/8.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "PhotoView.h"
#import "PhotoCell.h"

@implementation PhotoView

- (instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout {
    
    self = [super initWithFrame:frame collectionViewLayout:layout];
    if(self) {
        
        self.delegate = self;
        self.dataSource = self;
        self.pagingEnabled = YES;
        [self registerClass:[PhotoCell class] forCellWithReuseIdentifier:@"PhotoCell"];
    }
    return self;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return __dataArr.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    PhotoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PhotoCell" forIndexPath:indexPath];
    cell.imageUrl = __dataArr[indexPath.row];
    return cell;
}



@end
