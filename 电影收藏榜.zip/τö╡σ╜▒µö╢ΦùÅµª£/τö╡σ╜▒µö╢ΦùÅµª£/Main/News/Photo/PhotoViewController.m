//
//  PhotoViewController.m
//  项目一
//
//  Created by mac on 16/7/8.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "PhotoViewController.h"
#import "PhotoCell.h"
#import "PhotoView.h"
#import "PhotoFlowLayout.h"

@interface PhotoViewController ()

@end

@implementation PhotoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self createUI];
}

- (void)createUI {
    
    PhotoFlowLayout *layout = [[PhotoFlowLayout alloc] init];
    
    PhotoView *view = [[PhotoView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
    
    [self.view addSubview:view];
    
    view._dataArr = _imageUrl;
    
    [view scrollToItemAtIndexPath:_selectionIndexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
    
}
@end
