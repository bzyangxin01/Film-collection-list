//
//  PhotoViewController.h
//  项目一
//
//  Created by mac on 16/7/8.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "BaseViewController.h"

@interface PhotoViewController : BaseViewController

@property(strong,nonatomic)NSArray *imageUrl;

@property(strong,nonatomic)NSIndexPath *selectionIndexPath;

@end
