//
//  PhotoViewController.h
//  电影收藏榜
//
//  Created by mac on 16/1/8.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "BaseViewController.h"

@interface PhotoViewController : BaseViewController

@property(strong,nonatomic)NSArray *imageUrl;

@property(strong,nonatomic)NSIndexPath *selectionIndexPath;

@end
