//
//  PhotoCell.m
//  电影收藏榜
//
//  Created by mac on 16/1/8.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "PhotoCell.h"
#import "UIImageView+WebCache.h"
#import "MBProgressHUD.h"
#import "UIView+ViewController.h"

@implementation PhotoCell {
    
    UIImageView *_imageView;
    UIAlertController *_alterctr;
    
}

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self) {
        
        [self _createImageView];
    }
    return self;
}

- (void)_createImageView {
    
    _imageView = [[UIImageView alloc] initWithFrame:self.bounds];
    _imageView.contentMode = UIViewContentModeScaleAspectFit;
    [self.contentView addSubview:_imageView];
    
    _imageView.userInteractionEnabled = YES;
    [_imageView addGestureRecognizer:[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(showPhoto:)]];
}
     
- (void)showPhoto:(UIGestureRecognizer *)ge {
    
    _alterctr = [UIAlertController alertControllerWithTitle:@"老司机要图么" message:@"你个若风" preferredStyle:UIAlertControllerStyleAlert];
    
    [_alterctr addAction:[UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        UIImage *img = _imageView.image;
        if(img) {
            
            MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.window animated:YES];
            UIImageWriteToSavedPhotosAlbum(img, self, @selector(image:didFinishSavingWithError:contextInfo:), (__bridge void *_Nullable)(hud));
        }
    }]];
    
    [_alterctr addAction:[UIAlertAction actionWithTitle:@"我很纯洁" style:UIAlertActionStyleDefault handler:NULL]];
    
    
    [self.viewController presentViewController:_alterctr animated:YES completion:NULL];
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    
    MBProgressHUD *hud = (__bridge MBProgressHUD *)(contextInfo);
    
    hud.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"37x-Checkmark"]];
    hud.mode = MBProgressHUDModeCustomView;
    hud.labelText = @"success";
    [hud hide:YES afterDelay:1.5];
    
    [_alterctr dismissViewControllerAnimated:YES completion:NULL];
}
     
- (void)setImageUrl:(NSString *)imageUrl {
    
    _imageUrl = imageUrl;
    [_imageView sd_setImageWithURL:[NSURL URLWithString:_imageUrl] placeholderImage:[UIImage imageNamed:@"yasuo"]];
}

@end
