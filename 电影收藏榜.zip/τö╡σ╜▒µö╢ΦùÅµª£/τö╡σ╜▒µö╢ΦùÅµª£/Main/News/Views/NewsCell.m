//
//  NewsCell.m
//  项目一
//
//  Created by mac on 16/7/6.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "NewsCell.h"
#import "NewsModel.h"
#import "UIImageView+WebCache.h"
@implementation NewsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setModel:(NewsModel *)model {
    
    _model = model;
    [_imgView sd_setImageWithURL:[NSURL URLWithString:_model.image] placeholderImage:[UIImage imageNamed:@"yasuo"]];
    _titleLabel.text = _model.title;
    _summaryLabel.text = _model.summary;
    
    //定义imagName
    NSString * imageName = nil;
    
    switch (_model.type) {
        case WordType:
            imageName = @"word";
            break;
            
        case ImgType:
            imageName = @"sctpxw";
            break;
            
        case VideoType:
            imageName = @"scspxw";
            break;
            
        default:
            break;
    }
    
    _typeView.image = [UIImage imageNamed:imageName];
    

}

@end
