//
//  imageCell.h
//  项目一
//
//  Created by mac on 16/7/8.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NewsCollectionModel;
@interface imageCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@property(strong,nonatomic)NewsCollectionModel *model;

@end
