//
//  imageCell.m
//  电影收藏榜
//
//  Created by mac on 16/1/8.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "imageCell.h"
#import "NewsCollectionModel.h"
#import "UIImageView+WebCache.h"

@implementation imageCell
- (void)awakeFromNib {
    
    [super awakeFromNib];
    self.layer.cornerRadius = 10;
    self.layer.masksToBounds = YES;
    
}

- (void)setModel:(NewsCollectionModel *)model {
    
    _model = model;
    
    [_imageView sd_setImageWithURL:[NSURL URLWithString:_model.image] placeholderImage:[UIImage imageNamed:@"yasuo"]];
    
}
@end
