//
//  CinemaCell.m
//  项目一
//
//  Created by mac on 16/7/12.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "CinemaCell.h"

@implementation CinemaCell

- (void)awakeFromNib {
    
    // Initialization code
}

- (void)setModel:(CinemaModel *)model {
    
    _model = model;
    
    //显示影院的名字
    _Name.text = _model.name;
    
    //评分
    _ratingLabel.text = _model.grade;
    
    //地址
    _adressLabel.text = _model.address;
    
    //价格
    _PriceLabel.text = [NSString stringWithFormat:@"$%@",_model.lowPrice];
    
    //距离
    _distance.text = @"1KM";
    
    //判读是否支持选座
    if ([_model.isSeatSupport integerValue] == 1)
    {
        _seatImageView.hidden = NO;
    }else
    {
        _seatImageView.hidden = YES;
    }
    
    //判读是否支持劵
    if ([_model.isCouponSupport integerValue] == 1)
    {
        _couponImgView.hidden = NO;
    }else
    {
        _couponImgView.hidden = YES;
    }

}
@end
