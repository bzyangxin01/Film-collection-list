//
//  SectionHeaderView.h
//  电影收藏榜
//
//  Created by mac on 16/1/13.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kSectionHeaderHeight 35

@interface SectionHeaderView : UITableViewHeaderFooterView


@property (weak,nonatomic,readonly)UIControl *ctrlView;

//组头城市名
@property (weak,nonatomic,readonly)UILabel * titleLabel;

@end
