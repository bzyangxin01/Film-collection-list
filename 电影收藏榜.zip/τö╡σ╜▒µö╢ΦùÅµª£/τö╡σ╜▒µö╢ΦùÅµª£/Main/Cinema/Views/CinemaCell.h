//
//  CinemaCell.h
//  电影收藏榜
//
//  Created by mac on 16/1/12.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CinemaModel.h"


@interface CinemaCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *seatImageView;
@property (weak, nonatomic) IBOutlet UIImageView *couponImgView;
@property (weak, nonatomic) IBOutlet UILabel *Name;
@property (weak, nonatomic) IBOutlet UILabel *adressLabel;
@property (weak, nonatomic) IBOutlet UILabel *ratingLabel;
@property (weak, nonatomic) IBOutlet UILabel *PriceLabel;
@property (weak, nonatomic) IBOutlet UILabel *distance;

@property(nonatomic,strong)CinemaModel *model;

@end
