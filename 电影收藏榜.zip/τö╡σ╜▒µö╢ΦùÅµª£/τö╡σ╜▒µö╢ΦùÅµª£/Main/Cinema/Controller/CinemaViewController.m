//
//  CinemaViewController.m
//  项目一
//
//  Created by mac on 16/7/4.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "CinemaViewController.h"
#import "CinemaModel.h"
#import "CinemaCell.h"
#import "SectionHeaderView.h"
#import "UIImageView+WebCache.h"
#import "WXDataService.h"


@interface CinemaViewController ()<UITableViewDelegate,UITableViewDataSource> {
    
    BOOL status[30];
}

@property (weak, nonatomic) IBOutlet UITableView *tbView;
@end

@implementation CinemaViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationItem.title = @"影院";
    
    [self _loadData];
    [self _createUI];
    
    _tbView.rowHeight = 75;
}

- (void)_loadData {
    
    NSDictionary *districtDic = [WXDataService loadData:@"district_list.json"];
    _districArr = districtDic[@"districtList"];
    
    _cinemaDic = [NSMutableDictionary dictionary];
    
    NSMutableDictionary *listDic = [WXDataService loadData:@"cinema_list.json"];
    NSArray *listArr = listDic[@"cinemaList"];
    
    for (NSDictionary *dic in listArr) {
        CinemaModel *model = [[CinemaModel alloc] init];
 
        NSString * districtId = dic[@"districtId"];
        
    
        NSMutableArray * cinemaArr = [_cinemaDic objectForKey:districtId];
        
        if (cinemaArr == nil)
        {
           
            cinemaArr = [NSMutableArray array];
            
        
            [_cinemaDic setObject:cinemaArr forKey:districtId];
        }
        model.lowPrice = dic[@"lowPrice"];
        model.grade = dic[@"grade"];
        model.address = dic[@"adress"];
        model.name = dic[@"name"];
        model.isSeatSupport = dic[@"isSeatSupport"];
        //是否有劵
        model.isCouponSupport = dic[@"isCouponSupport"];
        
        //所在区域的id
        model.districtId = dic[@"districtId"];
        
        [cinemaArr addObject:model];

    }
}

- (void)_createUI {
    
    self.tbView.separatorColor = [UIColor colorWithWhite:0.32 alpha:1];
    
    [self.tbView registerNib:[UINib nibWithNibName:@"CinemaCell" bundle:nil] forCellReuseIdentifier:@"KCinemaCellID"];
    
}


- (NSInteger )numberOfSectionsInTableView:(UITableView *)tableView
{
    return _districArr.count;
}

//返回每一组的行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (!status[section]) {
        return 0;
    }
    
    //根据组数获取区域 字典
    NSDictionary *dic = _districArr[section];
    /*
     {
     name: 东城
     
     
     key:  value
     id : 1019
     }
     */
    
    
    //根据id 获取所在的区域
    NSString * districtID = dic[@"id"];
    /*
     districtID = @"1019";
     
     */
    
    
    //根据id 获取 所对应的字典元素数组
    NSArray * arr =  _cinemaDic[districtID];
    /*
     {
     区域: "name":"东城区",
                 "id":"1019"
     districtId  :array[
     
					MODEL1,
					MODEL2,
     …… MODEL3,
					MODEL4
     
     ]
     }
     array .count;
     
     */
    
    return arr.count;
    
    
}

//创建每一个cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CinemaCell * cell  = [tableView dequeueReusableCellWithIdentifier:@"KCinemaCellID" forIndexPath:indexPath];
   
    NSDictionary *dic = _districArr[indexPath.section];
    //根据key id 获取  所对应的地区的ID
    NSString *districtID = dic[@"id"];
    //根据地区的ID获取 地区所有的影院
    NSArray *arr = _cinemaDic[districtID];
    //根据那一行找到 对应的 cell
    cell.model = arr[indexPath.row];
    
    return  cell;
}

//创建头视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    //创建头视图
    SectionHeaderView * headerView = [_tbView dequeueReusableHeaderFooterViewWithIdentifier:@"kCinemaHeaderFooterViewID"];
    
    if (headerView == nil)
    {
        headerView = [[SectionHeaderView alloc] initWithReuseIdentifier:@"kCinemaHeaderFooterViewID"];
        
        //添加点击事件
        [headerView.ctrlView addTarget:self action:@selector(clickSectionheader:) forControlEvents:UIControlEventTouchUpInside];
    }
    //设置tag值
    headerView.ctrlView.tag = 1000+section;
    
    //获取每组所对应的字典
    NSDictionary *dic = _districArr[section];
    //设置组标题
    headerView.titleLabel.text = dic[@"name"];
    
    return headerView;
}

//点击头视图调用的方法
-(void)clickSectionheader:(UIControl *)headView
{
    NSInteger section = headView.tag - 1000;
    status[section] = !status[section];
    
    //重新加载指定的部分使用给定的动画效果。
    [self.tbView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationFade];
}



@end
