//
//  CinemaModel.m
//  项目一
//
//  Created by mac on 16/7/12.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "CinemaModel.h"

@implementation CinemaModel

@end
