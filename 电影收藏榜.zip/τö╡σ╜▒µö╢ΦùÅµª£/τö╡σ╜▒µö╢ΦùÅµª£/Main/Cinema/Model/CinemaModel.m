//
//  CinemaModel.m
//  电影收藏榜
//
//  Created by mac on 16/1/12.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "CinemaModel.h"

@implementation CinemaModel

@end
