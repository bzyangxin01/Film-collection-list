//
//  CinemaModel.h
//  电影收藏榜
//
//  Created by mac on 16/1/12.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CinemaModel : NSObject

@property(nonatomic, copy)NSString *lowPrice;           //价格
@property(nonatomic, copy)NSString *grade;              //评分
@property(nonatomic, copy)NSString *coord;              //经纬度
@property(nonatomic, copy)NSString *address;            //地址
@property(nonatomic, copy)NSString *name;               //影院名称
@property(nonatomic, copy)NSString *cinemaModelId;      //id
@property(nonatomic, copy)NSString *districtId;         //所在区id
@property(nonatomic, copy)NSString *tel;                //电话
@property(nonatomic, copy)NSString *isSeatSupport;      //是否支持选座
@property(nonatomic, copy)NSString *isCouponSupport;    //是否支持优惠券
@property(nonatomic, copy)NSString *isImaxSupport;      //是否支持Imax
@property(nonatomic, copy)NSString *isGroupBuySupport;  //是否支持团购
@property(nonatomic, copy)NSString *circleName;       //商圈名字

@end
