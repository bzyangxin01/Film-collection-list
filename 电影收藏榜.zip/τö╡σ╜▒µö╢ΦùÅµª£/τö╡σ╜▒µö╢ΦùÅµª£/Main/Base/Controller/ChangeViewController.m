//
//  ChangeViewController.m
//  项目一
//
//  Created by mac on 16/7/13.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "ChangeViewController.h"
#import "MainTabBarController.h"

@interface ChangeViewController ()<UIScrollViewDelegate>

@end

@implementation ChangeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self _createUI];
    
}
- (void)_createUI {
    
    UIScrollView * scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    
   
    scrollView.pagingEnabled = YES;
  
    scrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width*4, [UIScreen mainScreen].bounds.size.height);
    
    scrollView.showsHorizontalScrollIndicator = NO;
    
    scrollView.delegate = self;
    
    for (int i = 0; i < 4; i++)
    {
        UIImageView * imgView = [[UIImageView alloc] initWithFrame:CGRectMake(i*[UIScreen mainScreen].bounds.size.width, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
        
       
        NSString *imgeName = [NSString stringWithFormat:@"%d.jpg",i+1];
        
        imgView.image = [UIImage imageNamed:imgeName];
        
        [scrollView addSubview:imgView];
        
    }
    
    [self.view addSubview:scrollView];
    

}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    if (scrollView.contentOffset.x == [UIScreen mainScreen].bounds.size.width * 3)
    {
        
        MainTabBarController * mainTbCtr = [[MainTabBarController alloc] init];
        
        
        [UIView transitionWithView:self.view.window  duration:1 options:UIViewAnimationOptionTransitionFlipFromLeft animations:^{
            
            self.view.window.rootViewController = mainTbCtr;
            
        } completion:NULL];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
