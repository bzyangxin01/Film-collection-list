//
//  MainTabBarController.m
//  项目一
//
//  Created by mac on 16/7/4.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "MainTabBarController.h"
#import "Common.pch"
#import "WXTabBarItem.h"
@class WXTabBarItem;
@interface MainTabBarController () {
    
    UIImageView *_selectImageView;
}

@end

@implementation MainTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"nav_bg_all-64"] forBarMetrics:UIBarMetricsDefault];
    
    [self _loadStoryboard];
}



- (void)_loadStoryboard {
    
    UIStoryboard *north = [UIStoryboard storyboardWithName:@"NorthUSA" bundle:nil];
    UIStoryboard *news = [UIStoryboard storyboardWithName:@"News" bundle:nil];
    UIStoryboard *top = [UIStoryboard storyboardWithName:@"Top" bundle:nil];
    UIStoryboard *cinema = [UIStoryboard storyboardWithName:@"Cinema" bundle:nil];
    UIStoryboard *more = [UIStoryboard storyboardWithName:@"More" bundle:nil];
    NSArray *viewctrs = @[[north instantiateInitialViewController],
                          [news instantiateInitialViewController],
                          [top instantiateInitialViewController],
                          [cinema instantiateInitialViewController],
                          [more instantiateInitialViewController]
                          ];
    self.viewControllers = viewctrs;
    
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    [self _createTabBar];
}
//设置Tabbar 移除item
- (void)_createTabBar {
    
    for (UIView *view in self.tabBar.subviews) {
        Class cls = NSClassFromString(@"UITabBarButton");
        if([view isKindOfClass:cls]) {
            [view removeFromSuperview];

        }
            }
    
    [self.tabBar setBackgroundImage:[UIImage imageNamed:@"tab_bg_all"]];
    
    //设置自定义按钮
    NSArray *imgArr = @[@"movie_home.png",
                        @"msg_new.png",
                        @"start_top250.png",
                        @"icon_cinema.png",
                        @"more_setting.png"
                        ];
    
    NSArray *titleArr = @[@"北美榜",
                          @"新闻",
                          @"Top",
                          @"影院",
                          @"更多"
                          ];
    
    _selectImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 50, 45)];
    _selectImageView.image = [UIImage imageNamed:@"selectTabbar_bg_all1"];

    [self.tabBar addSubview:_selectImageView];
    

    //按钮的宽高
    CGFloat width = kScreenWidth/imgArr.count;
    CGFloat height = CGRectGetHeight(self.tabBar.frame);
    
    for(int i = 0;i<imgArr.count;i++) {
        
        NSString *imgName = imgArr[i];
        NSString *titleName = titleArr[i];
        
        WXTabBarItem *item = [[WXTabBarItem alloc] initWithFrame:CGRectMake(i*width, 0, width, height) imageName:imgName titleName:titleName];
        
        //添加点击事件
        item.tag = 100+i;
        [item addTarget:self action:@selector(clickItem:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.tabBar addSubview:item];
        
        if(i == 0) {
            
            _selectImageView.center = item.center;
        }
        
        
    }
    
}

-(void)clickItem:(WXTabBarItem *)item {
    
    self.selectedIndex = item.tag-100;
    [UIView animateWithDuration:0.2 animations:^{
        _selectImageView.center = item.center;
    }];
}
@end
