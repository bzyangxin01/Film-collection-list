//
//  WXTabBarItem.h
//  电影收藏榜
//
//  Created by mac on 16/7/4.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WXTabBarItem : UIControl



- (id)initWithFrame:(CGRect)frame imageName:(NSString *)name titleName:(NSString *)title;
@end
