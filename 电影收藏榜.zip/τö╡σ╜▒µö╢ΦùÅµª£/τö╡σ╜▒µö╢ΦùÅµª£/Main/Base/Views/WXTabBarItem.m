//
//  WXTabBarItem.m
//  项目一
//
//  Created by mac on 16/7/4.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "WXTabBarItem.h"

@implementation WXTabBarItem

- (id)initWithFrame:(CGRect)frame imageName:(NSString *)name titleName:(NSString *)title {
    
    self = [super initWithFrame:frame];
    if(self) {
        
        //创建子视图
        UIImageView *imageView =[[UIImageView alloc] initWithFrame:CGRectMake((frame.size.width-20)/2, 5, 20, 20)];
        
        imageView.image = [UIImage imageNamed:name];
        
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        [self addSubview:imageView];
        //创建标题视图
        CGFloat maxY = CGRectGetMaxY(imageView.frame);
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, maxY, frame.size.width, 20)];
        //label.backgroundColor = [UIColor grayColor];
        label.text = title;
        label.textAlignment = NSTextAlignmentCenter;
        label.textColor = [UIColor whiteColor];
        label.font = [UIFont systemFontOfSize:11];
        
        
        [self addSubview:label];
        
    }
    return self;
    
}
@end
