//
//  UIView+ViewController.m
//  项目一
//
//  Created by mac on 16/7/8.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "UIView+ViewController.h"

@implementation UIView (ViewController)

- (UIViewController *)viewController {
    
    UIResponder *next = self.nextResponder;
    while (YES) {
        if([next isKindOfClass:[UIViewController class]]) {
            
            break;
        }
        next = next.nextResponder;
        
    }
    return (UIViewController *)next;
}
@end
