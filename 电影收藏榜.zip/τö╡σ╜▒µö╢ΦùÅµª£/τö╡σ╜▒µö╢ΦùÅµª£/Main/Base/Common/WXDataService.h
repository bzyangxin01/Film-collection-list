//
//  WXDataService.h
//  项目一
//
//  Created by mac on 16/7/6.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WXDataService : NSObject

+(id)loadData:(NSString *)fileName;
@end
