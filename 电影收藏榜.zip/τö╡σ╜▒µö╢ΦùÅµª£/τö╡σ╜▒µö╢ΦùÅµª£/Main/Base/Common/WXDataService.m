//
//  WXDataService.m
//  电影收藏榜
//
//  Created by mac on 16/7/6.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "WXDataService.h"

@implementation WXDataService

+(id)loadData:(NSString *)fileName {
     NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:nil];
    NSDate *data = [NSData dataWithContentsOfFile:filePath];
    
    id dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:NULL];
    return dic;
}
@end
