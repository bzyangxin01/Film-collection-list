//
//  UIView+ViewController.h
//  电影收藏榜
//
//  Created by mac on 16/1/8.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ViewController)

- (UIViewController *)viewController;
@end
