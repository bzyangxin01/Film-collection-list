//
//  Common.h
//  项目一
//
//  Created by mac on 16/7/4.
//  Copyright © 2016年 Simon. All rights reserved.
//

#ifndef Common_h
#define Common_h


#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

#import "WXDataService.h"

#define news_list news_list.json

#endif /* Common_h */
