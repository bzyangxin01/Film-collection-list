//
//  TopdeatilModel.h
//  项目一
//
//  Created by mac on 16/7/11.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TopdeatilModel : NSObject



@property(strong,nonatomic)NSString *userImages;
@property(strong,nonatomic)NSString *nickName;
@property(strong,nonatomic)NSString *ratings;
@property(strong,nonatomic)NSString *contents;

@end
