//
//  TopModel.h
//  项目一
//
//  Created by mac on 16/7/11.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TopModel : NSObject

@property(copy,nonatomic)NSString *title;
@property(strong,nonatomic)NSDictionary *images;
@property(strong,nonatomic)NSDictionary *rating;

@end
