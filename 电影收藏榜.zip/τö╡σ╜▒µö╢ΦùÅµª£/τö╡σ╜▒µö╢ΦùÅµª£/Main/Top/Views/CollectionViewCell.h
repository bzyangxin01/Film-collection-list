//
//  CollectionViewCell.h
//  电影收藏榜
//
//  Created by mac on 16/1/11.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TopModel;
@class startView;

@interface CollectionViewCell : UICollectionViewCell
{
    
    __weak IBOutlet UIImageView *imgView;
    
    __weak IBOutlet UILabel *titleLabel;
    
    __weak IBOutlet startView *starView;
    
    __weak IBOutlet UILabel *ratingLabel;
}


@property(strong,nonatomic)TopModel *model;

@end
