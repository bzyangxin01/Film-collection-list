//
//  CollectionViewCell.m
//  电影收藏榜
//
//  Created by mac on 16/1/11.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "CollectionViewCell.h"
#import "TopModel.h"
#import "startView.h"
#import "UIImageView+WebCache.h"

@implementation CollectionViewCell


- (void)setModel:(TopModel *)model {
    _model = model;
    
    self.contentView.transform = CGAffineTransformMakeScale(0.7, 1);
    
    NSString *imgStr = [_model.images objectForKey:@"medium"];
    [imgView sd_setImageWithURL:[NSURL URLWithString:imgStr] placeholderImage:[UIImage imageNamed:@"yasuo"]];
    titleLabel.text = model.title;
    NSNumber *ratingNum = [model.rating objectForKey:@"average"];
    ratingLabel.text = [NSString stringWithFormat:@"%.1f",[ratingNum floatValue]];
    starView.rating = [ratingNum floatValue];
    
}
@end
