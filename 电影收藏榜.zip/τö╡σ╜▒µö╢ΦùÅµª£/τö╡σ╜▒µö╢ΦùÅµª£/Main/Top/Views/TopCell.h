//
//  TopCell.h
//  电影收藏榜
//
//  Created by mac on 16/1/11.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TopdeatilModel;

@interface TopCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgeView;
@property (weak, nonatomic) IBOutlet UILabel *NameLabel;
@property (weak, nonatomic) IBOutlet UILabel *ratingLabel;
@property (weak, nonatomic) IBOutlet UILabel *readLabel;

@property(strong,nonatomic)TopdeatilModel *model;

@end
