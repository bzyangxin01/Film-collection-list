//
//  TopCell.m
//  项目一
//
//  Created by mac on 16/7/11.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "TopCell.h"
#import "TopdeatilModel.h"
#import "UIImageView+WebCache.h"

@implementation TopCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setModel:(TopdeatilModel *)model {
    
    _model = model;
    [_imgeView sd_setImageWithURL:[NSURL URLWithString:_model.userImages] placeholderImage:[UIImage imageNamed:@"yasuo"]];
    _NameLabel.text = _model.nickName;
    _readLabel.text = _model.contents;
    _ratingLabel.text = _model.ratings;
    
}


@end
