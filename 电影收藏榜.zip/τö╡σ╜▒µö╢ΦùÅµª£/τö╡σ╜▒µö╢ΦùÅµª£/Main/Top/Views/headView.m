//
//  headView.m
//  电影收藏榜
//
//  Created by mac on 16/1/12.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "headView.h"
#import "UIImageView+WebCache.h"
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>
#import "UIView+ViewController.h"

@implementation headView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)awakeFromNib {
    
     [super awakeFromNib];
    
   
        [_imgVIew sd_setImageWithURL:[NSURL URLWithString:@"http:img31.mtime.cn/mt/2012/06/28/131128.94272291.jpg"] placeholderImage:[UIImage imageNamed:@"yasuo"]];
        _titleCn.text = @"摩尔庄园2海妖宝藏";
        _titleEn.text = @"Legend of The Moles-Treasure of Scylla";
        _content.text = @"摩尔庄园大电影系列第二部：《摩尔庄园海妖宝藏》继续讲述快乐、勇敢、热爱和平的小摩尔们战胜邪恶";
        
        NSString *imgurl1 = @"http://img21.mtime.cn/mg/2012/04/23/212649.32521220.jpg";
        UIImage *img1 = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imgurl1]]];
        [_button1 setImage:img1 forState:UIControlStateNormal];
        
        NSString *imgurl2 = @"http://img31.mtime.cn/mg/2012/06/21/104707.90912302.jpg";
        UIImage *img2 = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imgurl2]]];
        [_button2 setImage:img2 forState:UIControlStateNormal];
        
        NSString *imgurl3 = @"http://img31.mtime.cn/mg/2012/06/21/112031.62936983.jpg";
        UIImage *img3 = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imgurl3]]];
        [_button3 setImage:img3 forState:UIControlStateNormal];
        
        NSString *imgurl4 = @"http://img31.mtime.cn/mg/2012/06/21/104707.90912302.jpg";
        UIImage *img4 = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imgurl4]]];
        [_button4 setImage:img4 forState:UIControlStateNormal];
        
    
}
- (IBAction)buttonAction1:(UIButton *)sender {
    
    NSString *url = @"http://vf1.mtime.cn/Video/2012/04/23/mp4/120423212602431929.mp4";
    AVPlayerViewController *moviePlayer = [[AVPlayerViewController alloc] init];
    AVPlayer *player = [AVPlayer playerWithURL:[NSURL URLWithString:url]];
    moviePlayer.player = player;
    [player play];
    
    [self.viewController presentViewController:moviePlayer animated:YES completion:NULL];
    
    
}
- (IBAction)buttonAciton2:(UIButton *)sender {
    
    NSString *url = @"http://vf1.mtime.cn/Video/2012/06/21/mp4/120621104820876931.mp4";
    AVPlayerViewController *moviePlayer = [[AVPlayerViewController alloc] init];
    AVPlayer *player = [AVPlayer playerWithURL:[NSURL URLWithString:url]];
    moviePlayer.player = player;
    [player play];
    
    [self.viewController presentViewController:moviePlayer animated:YES completion:NULL];
}
- (IBAction)buttonAction3:(UIButton *)sender {
    
    NSString *url = @"http://vf1.mtime.cn/Video/2012/06/21/mp4/120621112404690593.mp4";
    AVPlayerViewController *moviePlayer = [[AVPlayerViewController alloc] init];
    AVPlayer *player = [AVPlayer playerWithURL:[NSURL URLWithString:url]];
    moviePlayer.player = player;
    [player play];
    
    [self.viewController presentViewController:moviePlayer animated:YES completion:NULL];
}
- (IBAction)buttonAction4:(UIButton *)sender {
    
    NSString *url = @"http://vf1.mtime.cn/Video/2012/06/21/mp4/120621104820876931.mp4";
    AVPlayerViewController *moviePlayer = [[AVPlayerViewController alloc] init];
    AVPlayer *player = [AVPlayer playerWithURL:[NSURL URLWithString:url]];
    moviePlayer.player = player;
    [player play];
    
    [self.viewController presentViewController:moviePlayer animated:YES completion:NULL];
}

@end
