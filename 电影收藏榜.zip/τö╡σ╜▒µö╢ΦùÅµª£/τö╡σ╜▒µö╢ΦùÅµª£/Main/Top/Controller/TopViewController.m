//
//  TopViewController.m
//  电影收藏榜
//
//  Created by mac on 16/7/4.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "TopViewController.h"
#import "TopModel.h"
#import "WXDataService.h"
#import "CollectionViewCell.h"
#import "BackViewController.h"

#define KItemCount 3
#define KItemWidth 100
#define KItemHeight 160

@interface TopViewController ()<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UICollectionViewFlowLayout *flowLayout;

@property(strong,nonatomic)NSMutableArray *dataArr;

@end

@implementation TopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"首页";
    
    [self _loadData];
    [self _createUI];
    
    
}

- (void)_loadData {
    
    _dataArr = [NSMutableArray array];
    
    NSDictionary *jsonDic = [WXDataService loadData:@"top250.json"];
    NSArray *jsonArr = jsonDic[@"subjects"];
    
    for (NSDictionary *dic in jsonArr) {
        TopModel *model = [[TopModel alloc]init];
        
        model.title = dic[@"title"];
        model.rating = dic[@"rating"];
        model.images = dic[@"images"];
        
        [_dataArr addObject:model];
    }
    
}

- (void)_createUI {
    
    self.flowLayout.itemSize = CGSizeMake(KItemWidth, KItemHeight);
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return _dataArr.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
   CollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"collectionCellID" forIndexPath:indexPath];
    
    cell.model = _dataArr[indexPath.row];
    
    return cell;
    
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    BackViewController *viewctr = [self.storyboard instantiateViewControllerWithIdentifier:@"BackViewControllerID"];
    
    viewctr.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:viewctr animated:YES];

}



@end
