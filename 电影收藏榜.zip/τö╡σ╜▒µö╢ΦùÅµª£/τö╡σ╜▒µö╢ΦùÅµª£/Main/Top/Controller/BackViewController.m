//
//  BackViewController.m
//  电影收藏榜
//
//  Created by mac on 16/1/11.
//  Copyright © 2016年 Simon. All rights reserved.
//

#import "BackViewController.h"
#import "TopdeatilModel.h"
#import "TopCell.h"
#import "WXDataService.h"
#import "UIImageView+WebCache.h"
#import "headView.h"

@interface BackViewController()<UITableViewDelegate,UITableViewDataSource> {
    
    headView *_headView;
}

@property(strong,nonatomic)NSMutableArray *dataArr;
@property (strong,nonatomic)NSIndexPath * selecIndePath;


@end

@implementation BackViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self _createUI];
    
    [self _loadData];
    
    _tbView.rowHeight = 80;
}

- (void)_loadData {
    _dataArr = [NSMutableArray array];
    
    NSDictionary *jsonDic1 = [WXDataService loadData:@"movie_comment.json"];
   
    NSArray *jsonArr = jsonDic1[@"list"];
    for (NSDictionary *dic in jsonArr) {
        
        TopdeatilModel *model = [[TopdeatilModel alloc]init];
        model.ratings = dic[@"rating"];
        model.contents = dic[@"content"];
        model.userImages = dic[@"userImage"];
        model.nickName = dic[@"nickname"];
        
        [_dataArr addObject:model];
    }
    
}

- (void)_createUI {
    
    _headView = [[[NSBundle mainBundle] loadNibNamed:@"headView" owner:self options:nil] lastObject];
    
    _tbView.tableHeaderView = _headView;
    
    [_tbView registerNib:[UINib nibWithNibName:@"TopCell" bundle:nil] forCellReuseIdentifier:@"topcellID"];
    
//    [self];
    
}

- (CGFloat )tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_selecIndePath isEqual:indexPath]) {
        
        //获取数据
        TopdeatilModel * model = _dataArr[indexPath.row];
        
        
        //设置子体的大小
        NSDictionary * arrtDic = @{
                                   NSFontAttributeName :[UIFont systemFontOfSize:16]
                                   };
        
        //返回一个frame
        CGRect  frame = [model.contents boundingRectWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width-114, 2000) options:NSStringDrawingUsesLineFragmentOrigin attributes:arrtDic context:nil];
        
        //
        CGFloat height = frame.size.height+100;
        
        return height;
        
    }else{
        return 80;
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (![_selecIndePath isEqual:indexPath])
    {
        _selecIndePath = indexPath;
        
        //
        [_tbView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}




- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    TopCell * cell = [tableView dequeueReusableCellWithIdentifier:@"topcellID" forIndexPath:indexPath];
    
       //传输数据
    cell.model = _dataArr[indexPath.row];

    return cell;
}


    
    





@end
